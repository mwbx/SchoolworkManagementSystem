create definer = root@`%` trigger student_insert_to_login
    after insert
    on student
    for each row
BEGIN
	INSERT INTO login(login_account,login_pwd,login_type)
	VALUES(new.student_account,'123','2');
END;

