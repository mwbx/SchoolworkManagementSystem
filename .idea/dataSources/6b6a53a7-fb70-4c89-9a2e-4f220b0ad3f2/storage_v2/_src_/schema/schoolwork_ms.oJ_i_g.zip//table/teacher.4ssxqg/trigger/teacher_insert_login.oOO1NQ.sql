create definer = root@`%` trigger teacher_insert_login
    after insert
    on teacher
    for each row
BEGIN
	INSERT INTO login(login_account,login_pwd,login_type)
	VALUES(new.teacher_account,'123','1');
END;

