create definer = root@`%` trigger admin_insert_login
    after insert
    on admin
    for each row
BEGIN
	INSERT INTO login(login_account,login_pwd,login_type)
	VALUES(new.admin_account,'123','0');
END;

